TITLE: Digital Ofrenda: A Private Remembrance Writer That Runs Offline with Ollama

(Paste everything below this line into the DEV editor body. Replace the [BRACKETS]. Delete this top note.)

---

*This is a submission for the [Hacktoberfest Open-Source AI Challenge Week 4: Ghost in the Machine](https://dev.to/challenges/hacktoberfest-week4-2026-10-26)*

## What I Built

Digital Ofrenda is a small web app for Día de los Muertos. You tell it about someone you remember: their name, who they were to you, their favorite food, their favorite song and one memory. A language model running on your own computer writes a short remembrance, while an altar on screen lights its candles and places the food and song as offerings. You can add a photo, and it appears in the frame at the top of the altar.

I read "Ghost in the Machine" as the people who live on in stories, not as something scary. The machine here is a local model, and the ghost is the memory you give it. Each remembrance is saved as a plain text file, so it belongs to you and can be printed or shared with family. [ADD ONE SENTENCE: who you thought of while building this.]

## Demo

[PASTE YOUR SCREENSHOT OR SCREEN RECORDING HERE. Tip: record the candles lighting and the text streaming in.]

## Code

{% embed https://github.com/[YOUR-USERNAME]/digital-ofrenda %}

## How I Built It

- **Model:** an open-weight model through [Ollama](https://ollama.com). I used `llama3.2`, and the app lists every model you have installed in a dropdown so you can switch to Qwen, Gemma or Mistral.
- **Backend:** a Python server using only the standard library (`app.py`). It builds the prompt, calls Ollama's local API at `localhost:11434`, streams the reply to the browser, and saves it to the `ofrendas/` folder.
- **Frontend:** one HTML file with no external fonts, scripts or images. The altar, marigolds and candle flames are plain CSS.
- **Prompt design:** the model is told to use only the facts the person entered. That stops it from inventing details about someone's grandmother, which matters a lot for a remembrance. It can also write in English or Spanish.
- **Error handling:** if Ollama isn't running or the model isn't installed, the page says exactly what command to run.

[ADD 1-2 LINES ABOUT A PROBLEM YOU HIT AND HOW YOU FIXED IT, for example a slow model or an error message.]

## Why Does Open Innovation Matter?

A remembrance is some of the most personal writing a person does. Sending a grandmother's name and a private memory to a cloud API felt wrong for this project, so open models were the point, not just a convenience:

- **Privacy:** names, photos and stories never leave the laptop.
- **Works with the lights off:** after the one-time model download, it needs no internet.
- **Free:** no API key, no usage fees, no account.
- **Not locked into a service:** a closed API can change, get more expensive or shut down. A file on my disk and a model I can download again will still work next year, when the altar goes up again.
- **Swappable:** changing the model is one dropdown, so I can try a smaller model on a slow laptop or a better one on a stronger machine.

## The Spirit of It

[OPTIONAL BUT RECOMMENDED: show one person (a parent, grandparent or friend) the app and write what happened. One or two real sentences are enough, for example: "I typed in my [relative]'s favorite dish, and [name] smiled and told me a story I had never heard." If you can't, delete this section.]

## Prize Categories

[DELETE THIS SECTION unless you are entering a partner category.]
