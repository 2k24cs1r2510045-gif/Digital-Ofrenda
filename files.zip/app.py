"""
Digital Ofrenda - a private, offline remembrance writer.
Serves a small web page and streams text from a local open-weight model via Ollama.
Only the Python standard library is used. Nothing leaves your computer.

Run:  python app.py      then open http://localhost:8000
"""
import json
import os
import pathlib
import urllib.error
import urllib.request
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

OLLAMA = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
DEFAULT_MODEL = os.environ.get("OFRENDA_MODEL", "llama3.2")
PORT = int(os.environ.get("PORT", "8000"))
ROOT = pathlib.Path(__file__).parent
SAVE_DIR = ROOT / "ofrendas"


def build_prompt(d: dict) -> str:
    lang = "Spanish" if d.get("language") == "es" else "English"
    return f"""You are helping someone write a short remembrance for their ofrenda,
the altar made for Dia de los Muertos. Write in {lang}, in warm, simple, respectful language.

Use ONLY these facts. Do not invent names, places, dates or events.
- Name: {d['name']}
- Who they were to the writer: {d['relation']}
- Favorite food: {d['food']}
- Favorite song: {d['song']}
- A memory: {d['memory']}

Write 120 to 150 words in the first person, as the writer speaking about {d['name']}.
Mention the food and the song naturally and weave in the memory.
End with one gentle line about keeping their story alive. No headings, no lists."""


def save(d: dict, text: str) -> None:
    SAVE_DIR.mkdir(exist_ok=True)
    safe = "".join(c for c in d["name"] if c.isalnum() or c in " -_").strip().replace(" ", "_")
    path = SAVE_DIR / f"{safe or 'ofrenda'}_{date.today().isoformat()}.txt"
    path.write_text(
        f"Ofrenda for {d['name']} ({d['relation']})\n"
        f"Favorite food: {d['food']}\nFavorite song: {d['song']}\n\n{text.strip()}\n",
        encoding="utf-8",
    )


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body: bytes, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, (ROOT / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif self.path == "/api/models":
            try:
                with urllib.request.urlopen(f"{OLLAMA}/api/tags", timeout=5) as r:
                    names = [m["name"] for m in json.load(r).get("models", [])]
                self._send(200, json.dumps({"models": names, "default": DEFAULT_MODEL}).encode())
            except (urllib.error.URLError, OSError):
                self._send(502, json.dumps({"error": "ollama_down"}).encode())
        else:
            self._send(404, b"{}")

    def do_POST(self):
        if self.path != "/api/remember":
            return self._send(404, b"{}")
        data = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
        body = json.dumps({
            "model": data.get("model") or DEFAULT_MODEL,
            "prompt": build_prompt(data),
            "stream": True,
        }).encode()
        req = urllib.request.Request(
            f"{OLLAMA}/api/generate", data=body, headers={"Content-Type": "application/json"}
        )
        try:
            resp = urllib.request.urlopen(req, timeout=300)
        except urllib.error.HTTPError:
            return self._send(404, json.dumps({"error": "model_missing"}).encode())
        except (urllib.error.URLError, OSError):
            return self._send(502, json.dumps({"error": "ollama_down"}).encode())

        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()  # no Content-Length: the connection closing ends the stream
        text = ""
        with resp:
            for line in resp:
                chunk = json.loads(line)
                piece = chunk.get("response", "")
                text += piece
                self.wfile.write(piece.encode("utf-8"))
                self.wfile.flush()
                if chunk.get("done"):
                    break
        save(data, text)

    def log_message(self, *args):  # keep the terminal quiet
        pass


if __name__ == "__main__":
    print(f"Digital Ofrenda running at http://localhost:{PORT}  (model: {DEFAULT_MODEL})")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
