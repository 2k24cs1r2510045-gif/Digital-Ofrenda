# Digital Ofrenda

A private, offline tool for writing a remembrance for someone you miss, made for Día de los Muertos.
You enter a name, favorite food, favorite song and a memory. A local open-weight model writes the
remembrance while an altar lights up on screen. Everything runs on your own computer.

Built for the Hacktoberfest Open-Source AI Challenge, Week 4: Ghost in the Machine.

## Why open-source AI
- Works offline once the model is downloaded.
- Names, photos and family stories never leave your machine.
- Free to run, no API keys.
- Swap models from a dropdown (Llama, Qwen, Gemma, Mistral...).

## Setup
1. Install [Ollama](https://ollama.com) and download a model:
   ```
   ollama pull llama3.2
   ```
2. Make sure Ollama is running (the desktop app, or `ollama serve`).
3. Start the app (Python 3.8+, no packages to install):
   ```
   python app.py
   ```
4. Open http://localhost:8000

Remembrances are saved as text files in the `ofrendas/` folder.

## Options
- `OFRENDA_MODEL=qwen2.5 python app.py` sets the default model.
- `PORT=9000 python app.py` changes the port.
- On a slow laptop, try `ollama pull llama3.2:1b`.

## How it works
- `app.py`: a standard-library Python server. It builds a prompt that tells the model to use only the
  facts you gave, streams the reply from Ollama's local API, and saves it to a file.
- `index.html`: the altar interface. The photo you choose is only displayed in your browser and is never uploaded.
- No external fonts, scripts or images, so the page also works with the internet off.

## Ideas to extend
- Transcribe a spoken family story with a local Whisper model.
- Add more languages.
- Print the remembrance as a card.
